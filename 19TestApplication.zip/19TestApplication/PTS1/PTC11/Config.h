#pragma once
#include "../Config.h"

#define PTC11_SIZE_MEMORYBASE 500000
#define PTC11_COUNT_EXCEPTION 20
#define PTC11_COUNT_LOG 20
#define PTC11_COUNT_EVENT 40
