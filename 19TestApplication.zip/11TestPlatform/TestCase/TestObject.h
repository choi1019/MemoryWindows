#pragma once

#include "../typedef.h"
#define _TestObject_Id _GET_CLASS_UID(_ELayer_TestBase::_eTestObject)
#define _TestObject_Name "TestObject"

#include "../TestObject/TestRoot.h"
#include "../TestAspect/TestException.h"
#include "../TestAspect/TestLog.h"

class TestObject: public TestRoot
{
private:

public:
	TestObject(
		int nClassId = _TestObject_Id,
		const char *pClassName = _TestObject_Name)
		: TestRoot(nClassId, pClassName)
	{
	}

	virtual ~TestObject() {}

	virtual void Initialize() {
		TestRoot::Initialize();

		TestLog().PrintSeparator();
		TestLog(this->GetClassName(), __func__, "���� �մϴ�").Println();
		TestLog::AddTab();
	}

	virtual void Finalize() {
		TestLog::RemoveTab();
		TestLog(this->GetClassName(), __func__, "���� �Ǿ����ϴ�").Println();
		TestLog().PrintSeparator();

		TestRoot::Finalize();
	}

	virtual void Run() = 0;
};

