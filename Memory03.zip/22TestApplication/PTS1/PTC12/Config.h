#pragma once
#include "../Config.h"

#define PTC12_SIZE_MEMORYBASE 500000
#define PTC12_COUNT_EXCEPTION 20
#define PTC12_COUNT_LOG 20
#define PTC12_COUNT_EVENT 40
