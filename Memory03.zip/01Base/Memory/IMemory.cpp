#include "IMemory.h"

void* IMemory::s_pSystemMemoryAllocated = nullptr;
size_t IMemory::s_szSystemMemoryAllocated = 0;