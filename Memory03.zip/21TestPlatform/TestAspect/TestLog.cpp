#include "TestLog.h"

unsigned TestLog::s_uCount = 0;
unsigned TestLog::s_uCountTab = 0;
char TestLog::s_pcTab[COUNT_TAB * SIZE_TAB];