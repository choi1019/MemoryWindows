#include "TestException.h"

unsigned TestException::s_uCount = 0;