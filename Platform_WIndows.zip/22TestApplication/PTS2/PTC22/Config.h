#pragma once
#include "../Config.h"

#define PTC22_SIZE_MEMORYBASE 500000
#define PTC22_COUNT_EXCEPTION 20
#define PTC22_COUNT_LOG 20
#define PTC22_COUNT_EVENT 40
