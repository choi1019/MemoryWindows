#pragma once
#include "../Config.h"

#define PTC21_SIZE_MEMORYBASE 500000
#define PTC21_COUNT_EXCEPTION 20
#define PTC21_COUNT_LOG 20
#define PTC21_COUNT_EVENT 40
