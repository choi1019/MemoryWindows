#pragma once
#include "../PTestMain/Config.h"

enum class _ELayer_PTS2 {
	_eBegin = _GET_TESTCASE_UID(_ELayer_PTestSuit::_ePTS2),
	_ePTC21, 
	_eTMemroyManager21,
	_ePTC22,
	_eTMemroyManager22,
	_eEnd

};


