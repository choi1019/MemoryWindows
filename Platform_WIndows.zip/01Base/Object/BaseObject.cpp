#include "BaseObject.h"

IMemory* BaseObject::s_pMemory = nullptr;



