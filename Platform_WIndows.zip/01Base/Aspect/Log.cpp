#include "Log.h"

IMemory* Log::s_pMemory = nullptr;