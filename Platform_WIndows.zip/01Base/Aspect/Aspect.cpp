#include "Aspect.h"

unsigned Aspect::s_uCountTab = 1;
char Aspect::s_pcTab[COUNT_TAB * SIZE_TAB];