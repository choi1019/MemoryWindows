#include "Exception.h"

IMemory* Exception::s_pMemory = nullptr;