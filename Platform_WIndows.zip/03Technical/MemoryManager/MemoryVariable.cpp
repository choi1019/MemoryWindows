#include "MemoryVariable.h"

unsigned MemoryVariable::s_uCountMemory = 0;
