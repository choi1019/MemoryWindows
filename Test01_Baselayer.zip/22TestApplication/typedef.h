#pragma once

#include "../21TestPlatform/typedef.h"

enum class _ELayer_TestApplication {
	_eBegin = _GET_LAYER_UID(_ETestLayer::_eTestApplication),

	_ePTestMain,
		_ePTS1,
			_ePTC11,
			_ePTC12,

	_eEnd

};




