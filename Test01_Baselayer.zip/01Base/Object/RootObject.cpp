#include "RootObject.h"

unsigned RootObject::s_uCounter = 0;
