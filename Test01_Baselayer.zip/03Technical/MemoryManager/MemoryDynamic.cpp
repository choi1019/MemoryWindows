#include "MemoryDynamic.h"

//MemoryStatic* MemoryDynamic::s_pMemoryStatic = nullptr;
//size_t MemoryDynamic::s_szThis = 0;
