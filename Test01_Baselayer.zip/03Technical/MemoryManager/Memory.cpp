#include "Memory.h"

IMemory* Memory::s_pMemoryManager = nullptr;