#include "TestRoot.h"

unsigned TestRoot::s_uCounter = 0;
size_t TestRoot::s_szThis = 0;